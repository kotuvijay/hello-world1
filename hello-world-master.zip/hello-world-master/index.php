<!DOCTYPE html>
<html>
<body>

<body style="background-color:powderblue;">
<font size = "6"><p style="color:red">This is Stagging deployment Slot.</p></font>

<?php
echo "Azure App Service Example";
?> 

</body>
</html>
